package com.example.gatorrider;
import android.nfc.Tag;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.TextureView;
import android.widget.TextView;

public class GallaryActivity extends AppCompatActivity {
    private static final String TAG = "GallaryActivity";
    private int position;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallary);
        Log.d(TAG, "onCreate: started.");
        getIncomingIntent();
        TextView name = findViewById(R.id.textView);
        name.setText(Ride.rideList.get(position).getDriver());
    }

    private void getIncomingIntent() {
        Log.d(TAG, "getIncomingIntent: checking for incoming intents.");
        if (getIntent().hasExtra("Position")) {
            Log.d(TAG, "getIncomingIntent: found incoming intent.");
            position = getIntent().getIntExtra("Position", 0);
        }
    }
}