package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class FindRide extends AppCompatActivity {

    String origin;
    String destination;
    String date;
    String seats;
    String price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Person user = (Person) getIntent().getParcelableExtra("user_data");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_ride);
        final EditText _origin;
        final EditText _destination;
        final EditText _date;
        final EditText _seats;
        final EditText _price;

        Button find = findViewById(R.id.search);

        _origin =  findViewById(R.id.origin);
        _destination = findViewById(R.id.dest);
        _date = findViewById(R.id.date);
        _seats = findViewById(R.id.ppl);
        _price = findViewById(R.id.price);

        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                origin = _origin.getText().toString();
                destination = _destination.getText().toString();
                date = _date.getText().toString();
                seats = _seats.getText().toString();
                price = _price.getText().toString();


                ArrayList<Ride> availRides = Ride.findRide(origin, destination, seats, price, date);

                    RecyclerView recyclerView = findViewById(R.id.recycler_view);
                    RecyclerViewAdapter adapter = new RecyclerViewAdapter(availRides,v.getContext());
                    recyclerView.setAdapter(adapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(v.getContext()));


            }

        });


    }

}
