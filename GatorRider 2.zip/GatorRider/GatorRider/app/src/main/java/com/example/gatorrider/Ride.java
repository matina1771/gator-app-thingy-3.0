package com.example.gatorrider;

import android.os.Parcel;
import android.os.Parcelable;
import java.lang.Integer;
import java.util.ArrayList;

public class Ride implements Parcelable{

    public Ride (Parcel in) {
        String[] data = new String[4];
        in.readStringArray(data);
        // the order needs to be the same as in writeToParcel() method
        this.origin = data[0];
        this.destination = data[1];
        this.spots = data[2];
        this.price = data[3];
        this.driver = data[4];
        this.date = data[5];

    }

    public int describeContents(){
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[] {this.origin,
                this.destination,
                this.spots, this.price, this.driver, this.date});
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public Ride createFromParcel(Parcel in) {
            return new Ride(in);
        }

        public Ride[] newArray(int size) {
            return new Ride[size];
        }
    };

    final String[] locations = {"Gainesville" , "Ocala", "Orlando", "Jacksonville", "Sarasota", "Miami", "Tallahassee"};
    private String origin;
    private String destination;
    private String spots;
    private String price;
    private String driver;
    private String date;
    public static ArrayList<Ride> rideList = new ArrayList<>();
    public static ArrayList<Ride> sortedRides = new ArrayList();

    public Ride (String _origin, String _destination, String _spots, String _price, String _date, String driverName) {

        origin = _origin;
        destination = _destination;
        spots = _spots;
        price = _price;
        driver = driverName;
        date = _date;

    }

    public void addtoList(Ride ride) {
        rideList.add(ride);
    }

    static ArrayList<Ride> findRide(String origin, String destination, String spots, String price, String date) {
        for (int i = 0 ; i < rideList.size() ; i++) {
            if(origin.equals(rideList.get(i).getOrigin()) &&
                    destination.equals(rideList.get(i).getDestination()) &&
                    ((Integer.parseInt(spots) <= Integer.parseInt(rideList.get(i).getSpots())) &&
                            (Integer.parseInt(rideList.get(i).getPrice())) <= Integer.parseInt(price)) && date.equals(rideList.get(i).getDate())) {
                sortedRides.add(rideList.get(i));
            }
        }
        return sortedRides;
    }


    public String getOrigin() {
        return origin;
    }

    public String getDestination() {
        return destination;
    }

    public String getSpots() {
        return spots;
    }

    public void decreaseSpot () {
        int intspots = Integer.parseInt(spots) - 1;
        spots = Integer.toString(intspots);
    }

    public String getPrice() {
        return price;
    }

    public String getDate() {
        return date;
    }

    public void PrintRideList() {
        for (int i =0 ; i < rideList.size() ; i++) {
            rideList.get(i).Print();
        }
    }

    public String getDriver() {
        return driver;
    }

    public void Print() {
        System.out.println(driver + " is offering a ride from " + origin + " to " + destination + " on " + date);
        System.out.println("there are " + spots + " left in the car.");
        System.out.println("$" + price + " per person.");
    }
}
