package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Changepw extends AppCompatActivity {

    String oldpw;
    String newpw;
    String newpw1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Person user = (Person) getIntent().getParcelableExtra("user_data");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changepw);



        final EditText _oldpw;
        final EditText _newpw;
        final EditText _newpw1;
        Button done = findViewById(R.id.done);
        _oldpw =  findViewById(R.id.oldpw);
        _newpw = findViewById(R.id.newpw);
        _newpw1 = findViewById(R.id.newpw1);

        oldpw = _oldpw.getText().toString();
        newpw = _newpw.getText().toString();
        newpw1 = _newpw1.getText().toString();

        if (oldpw.equals(user.getPassword())) {
            if (newpw.equals(newpw1)) {
                user.setPassword(newpw);
            }
        }

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println(user.getPassword());
                Intent intent = new Intent(Changepw.this, Profile.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });

    }


}
