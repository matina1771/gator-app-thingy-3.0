package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class FindRide extends AppCompatActivity {

    String origin;
    String destination;
    String date;
    String seats;
    String price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Person user = (Person) getIntent().getParcelableExtra("user_data");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_ride);
        final EditText _origin;
        final EditText _destination;
        final EditText _date;
        final EditText _seats;
        final EditText _price;

        Button find = findViewById(R.id.search);

        _origin =  findViewById(R.id.origin);
        _destination = findViewById(R.id.dest);
        _date = findViewById(R.id.date);
        _seats = findViewById(R.id.ppl);
        _price = findViewById(R.id.price);

        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                origin = _origin.getText().toString();
                destination = _destination.getText().toString();
                date = _date.getText().toString();
                seats = _seats.getText().toString();
                price = _price.getText().toString();

                Intent intent = new Intent(FindRide.this, AvailRides.class);
                intent.putExtra("user_data", user);
                intent.putExtra("origin", origin);
                intent.putExtra("dest", destination);
                intent.putExtra("date", date);
                intent.putExtra("seats", seats);
                intent.putExtra("price", price);

                startActivity(intent);





            }

        });


    }

}
