package com.example.gatorrider;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GallaryActivity extends AppCompatActivity {
    private static final String TAG = "GallaryActivity";
    private int position;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        final Person user = (Person) getIntent().getParcelableExtra("user_data");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallary);
        Log.d(TAG, "onCreate: started.");
        getIncomingIntent();
        TextView name = findViewById(R.id.name);
        name.setText(Ride.rideList.get(position).getDriver());

        TextView price = (TextView) findViewById(R.id.price);
        price.setText(Ride.rideList.get(position).getPrice());

        TextView date = (TextView) findViewById(R.id.date);
        date.setText(Ride.rideList.get(position).getDate());

        TextView origin = (TextView) findViewById(R.id.origin);
        origin.setText(Ride.rideList.get(position).getOrigin());

        TextView dest = (TextView) findViewById(R.id.dest);
        dest.setText(Ride.rideList.get(position).getDestination());

        Button back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GallaryActivity.this, AvailRides.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });

        Button confirm = findViewById(R.id.confirm);
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GallaryActivity.this, Home.class);
                intent.putExtra("user_data", user);
                Ride.rideList.get(position).decreaseSpot();
                if (Integer.parseInt(Ride.rideList.get(position).getSpots())< 1) {
                    Ride.rideList.remove(Ride.rideList.get(position));
                }
                startActivity(intent);
            }

        });
    }

    private void getIncomingIntent() {
        Log.d(TAG, "getIncomingIntent: checking for incoming intents.");
        if (getIntent().hasExtra("Position")) {
            Log.d(TAG, "getIncomingIntent: found incoming intent.");
            position = getIntent().getIntExtra("Position", 0);
        }
    }
}