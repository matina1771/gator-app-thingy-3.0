package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        final Person user = (Person) getIntent().getParcelableExtra("user_data");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView name = (TextView) findViewById(R.id.name);
        name.setText("Name: " + user.getName());

        TextView gender = (TextView) findViewById(R.id.gender);
        gender.setText("Gender: " + user.getGender());

        TextView phone = (TextView) findViewById(R.id.phone);
        phone.setText("Phone num: " + user.getPhone());

        TextView email = (TextView) findViewById(R.id.email);
        email.setText("Email: " + user.getEmail());

        Button back = findViewById(R.id.home);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, Home.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });



    }
}
