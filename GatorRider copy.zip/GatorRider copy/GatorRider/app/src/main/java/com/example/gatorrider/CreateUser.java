package com.example.gatorrider;
import com.example.gatorrider.Person;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.CheckBox;

public class CreateUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button next = (Button) findViewById(R.id.signup);

        /*next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               EditText mEdit;
                TextView mText;

                mEdit = findViewById(R.id.Name);
                String name = mEdit.getText().toString();


                mEdit = findViewById(R.id.age);
                int age = Integer.parseInt(mEdit.getText().toString());

                int gender;

                CheckBox male = findViewById(R.id.Male);
                CheckBox female = findViewById(R.id.female);

                if (male.isChecked()) {
                    gender = 1;
                } else if (female.isChecked()){
                    gender = 2;
                } else {
                    gender = 1;
                }

                CheckBox pet = findViewById(R.id.pet);
                boolean petOk;
                if (pet.isChecked()) {
                    petOk = true;
                } else {
                    petOk = false;
                }

                Person user1 = new Person("Name", 1, gender, petOk);
                System.out.println(user1.getName() + " " + user1.getAge() + " " + user1.getGender() + " " + user1.isPetOK());

                Intent intent = new Intent(CreateUser.this, usernamepw.class);
                startActivity(intent);


            }

        }); */

    }

}
