package com.example.gatorrider;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //users.add(new Person("a", "b", "c", "d", "e", "f"));

        Button signUp = findViewById(R.id.signup);
        Button login = findViewById(R.id.login);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CreateNew.class);
                final List<Person> users = new ArrayList<>();
                final List<Ride> ridesAvailable = new ArrayList<>();
                startActivity(intent);
            }

        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CreateNew.class);


                startActivityForResult(intent,1);
                /*Intent intent = new Intent(MainActivity.this, Login.class);
                Bundle userList = new Bundle();
                userList.putParcelableArrayList("userList", users);
                intent.putExtra("data", userList);*/

                startActivity(intent);
            }

        });


    }
}



