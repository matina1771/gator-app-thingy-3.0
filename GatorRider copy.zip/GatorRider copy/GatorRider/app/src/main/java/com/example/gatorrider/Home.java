package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Person user = (Person) getIntent().getParcelableExtra("user_data");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button offer = findViewById(R.id.drive);
        Button ride = findViewById(R.id.ride);
        Button profile = findViewById(R.id.profile);

        offer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Home.this, RideCriteria.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Home.this, Profile.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });




    }
}
