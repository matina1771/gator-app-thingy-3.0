package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import java.lang.Integer;

public class CreateNew extends AppCompatActivity {

    String fullName;
    String userPhone;
    String gender;
    String email;
    String userName;
    String password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new);

        final EditText _firstname;
        final EditText _lastname;
        final EditText _phone;
        final EditText _email;
        final EditText _userName;
        final EditText _password;
        final CheckBox _male, _female;

        Button submit = findViewById(R.id.submit_sign);
        _firstname =  findViewById(R.id.firstnInput);
        _lastname = findViewById(R.id.lastnInput);
        _phone = findViewById(R.id.phone);
        _email = findViewById(R.id.email);
        _userName = findViewById(R.id.username);
        _password = findViewById(R.id.password);
        _male = findViewById(R.id.Male_check);
        _female = findViewById(R.id.Female_Check);



        _male.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (_male.isChecked()) {
                    gender = "male";
                } else {
                    gender = "female";
                }

            }

        });

        _female.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (_female.isChecked()) {
                    gender = "female";
                }
            }

        });




        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fullName = _firstname.getText().toString() + " " + _lastname.getText().toString();
                userPhone = _phone.getText().toString();
                email = _email.getText().toString();
                userName = _userName.getText().toString();
                password = _password.getText().toString();

                System.out.println(userName + " " + userPhone + " " + gender);

                Person user1 = new Person (fullName, userPhone, gender, email, userName, password);


                Intent intent = new Intent(CreateNew.this, UserProfile.class);
                intent.putExtra("user_data", user1);
                startActivity(intent);
            }

        });
    }
}
