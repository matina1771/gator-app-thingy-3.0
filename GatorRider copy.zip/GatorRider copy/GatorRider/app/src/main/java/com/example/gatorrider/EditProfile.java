package com.example.gatorrider;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class EditProfile extends AppCompatActivity {

    String fullName;
    String userPhone;
    String gender;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        final EditText _firstname;
        final CheckBox _male, _female;
        final EditText _phone;
        final EditText _email;

        Button done = findViewById(R.id.done);
        _firstname =  findViewById(R.id.firstnInput);
        _phone = findViewById(R.id.phone);
        _email = findViewById(R.id.email);
        _male = findViewById(R.id.male);
        _female = findViewById(R.id.female);

        



    }
}
